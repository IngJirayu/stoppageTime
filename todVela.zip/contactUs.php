<?php
    require "header.php";
    require "navbar.php";
?>

<div class="announcementWrapper">
    <div class="announcementSecondWrapper">
        <div class="announcementHeader">
           ช่องทางการติดต่อ
        </div>  
        <div class="announcementText"> 
        กดลิ้งด้านล่างตามช่องทางที่สะดวกได้เลย
        <br>
        <br>
        ผ่าน <a href="https://www.facebook.com/Tod-Vela-117238983904516/">facebook</a> 
        <br>
        <br>
        ผ่าน <a href="https://lin.ee/0nbvBBp">ไลน์@ </a> คลิกที่ลิ้งค์หรือพิม @555knvoo
        </div>
    </div>    
</div>