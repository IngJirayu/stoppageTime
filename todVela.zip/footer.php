<div class="footerBx">
    <a href="contactUs.php">ติดต่อเรา</a>
</div>